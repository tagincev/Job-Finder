package com.aksantara.jobfinder.ui.login.register.option.nationality.experience.education

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.JfSpinnerModel
import com.aksantara.jobfinder.databinding.FragmentJfEducationBinding
import com.aksantara.jobfinder.ui.login.register.option.nationality.experience.education.interest.InterestFragment
import com.aksantara.jobfinder.utils.JfSpinnerAdapter

class EducationFragment : Fragment() {

    private lateinit var binding: FragmentJfEducationBinding

    private val listYears = listOf<JfSpinnerModel>(
        JfSpinnerModel(null, "2014"),
        JfSpinnerModel(null, "2015"),
        JfSpinnerModel(null, "2016"),
        JfSpinnerModel(null, "2017"),
        JfSpinnerModel(null, "2018"),
        JfSpinnerModel(null, "2019"),
        JfSpinnerModel(null, "2020"),
        JfSpinnerModel(null, "2021"),
        JfSpinnerModel(null, "2022"),
    )


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfEducationBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            spinnerStartYear.adapter = JfSpinnerAdapter(listYears, requireContext())
            spinnerEndYear.adapter = JfSpinnerAdapter(listYears, requireContext())

            btnBack.setOnClickListener {
                requireActivity().supportFragmentManager.popBackStackImmediate()
            }

            btnNext.setOnClickListener {
                requireActivity().supportFragmentManager.commit {
                    replace(R.id.host_register_activity, InterestFragment())
                    addToBackStack(null)
                }
            }

            linearLayout16.setOnClickListener {
                switch16.isChecked = !switch16.isChecked
            }
        }
    }
}