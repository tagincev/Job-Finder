package com.aksantara.jobfinder.ui.detail.detailcompany.aboutcompany

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.aksantara.jobfinder.databinding.FragmentJfAboutCompanyBinding
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage

class JfAboutCompanyFragment : Fragment() {

    private lateinit var binding: FragmentJfAboutCompanyBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfAboutCompanyBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            //iv company gallery
            ivCompanyGallery1.loadImage("https://picsum.photos/490/490")
            ivCompanyGallery2.loadImage("https://picsum.photos/493/490")
            ivCompanyGallery3.loadImage("https://picsum.photos/494/490")

            //iv people
            ivPeople1.loadImage("https://picsum.photos/460/462")
            ivPeople2.loadImage("https://picsum.photos/460/464")
            ivPeople3.loadImage("https://picsum.photos/460/465")
            ivPeople4.loadImage("https://picsum.photos/460/466")
        }
    }

}