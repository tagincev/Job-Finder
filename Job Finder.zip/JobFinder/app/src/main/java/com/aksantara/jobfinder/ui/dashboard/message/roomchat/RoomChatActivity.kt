package com.aksantara.jobfinder.ui.dashboard.message.roomchat

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.ActivityRoomChatBinding

class RoomChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRoomChatBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRoomChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setCurrentFragment(JfRoomChatFragment())

    }

    private fun setCurrentFragment(fragment: Fragment) {
        supportFragmentManager.commit {
            replace(R.id.host_message_activity, fragment)
        }
    }
}