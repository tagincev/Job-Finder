package com.aksantara.jobfinder.ui.login.forgotpassword

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.ActivityForgotPasswordBinding

class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var binding: ActivityForgotPasswordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            supportFragmentManager.commit {
                replace(R.id.host_forgot_password_activity, ForgotPasswordFragment())
            }
        }
    }
}