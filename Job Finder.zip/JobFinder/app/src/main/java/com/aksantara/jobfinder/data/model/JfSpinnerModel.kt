package com.aksantara.jobfinder.data.model

data class JfSpinnerModel(
    val imageSpinner: Int?,
    val textSpinner: String
)