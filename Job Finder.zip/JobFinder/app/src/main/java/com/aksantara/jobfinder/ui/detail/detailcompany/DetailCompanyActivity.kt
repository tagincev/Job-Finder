package com.aksantara.jobfinder.ui.detail.detailcompany

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.aksantara.jobfinder.databinding.ActivityDetailCompanyBinding
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage
import com.google.android.material.tabs.TabLayoutMediator

class DetailCompanyActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailCompanyBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailCompanyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            btnBack.setOnClickListener {
                onBackPressedDispatcher.onBackPressed()
            }

            viewPagerDetaiCompany.adapter = JfDetailCompanyPagerAdapter(this@DetailCompanyActivity)

            ivBackgroundHeader.loadImage("https://picsum.photos/460/460")

            ivCompany.loadImage("https://picsum.photos/360/360")
        }

        TabLayoutMediator(binding.tabLayout, binding.viewPagerDetaiCompany) {tab, position ->
            tab.text = when (position) {
                0 -> "About Company"
                1 -> "Available Jobs"
                else -> ""
            }
        }.attach()
    }
}