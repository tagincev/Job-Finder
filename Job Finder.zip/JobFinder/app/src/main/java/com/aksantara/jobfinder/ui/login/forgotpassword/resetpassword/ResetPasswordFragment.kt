package com.aksantara.jobfinder.ui.login.forgotpassword.resetpassword

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.DialogFragmentModel
import com.aksantara.jobfinder.databinding.FragmentJfResetPasswordBinding
import com.aksantara.jobfinder.ui.login.LoginActivity
import com.aksantara.jobfinder.ui.login.dialogfragment.DialogFragmentJf

class ResetPasswordFragment : Fragment() {

    private lateinit var binding: FragmentJfResetPasswordBinding

    private val resetData = DialogFragmentModel(
        R.drawable.ic_jf_reset_succes,
        "Your Password Is Recovered!",
        "Your new password has been recorded! Don’t forget it next time.",
        "Finished",
        LoginActivity.LOGIN_TEXT
    )

    companion object {
        private val TAG = ResetPasswordFragment::class.simpleName
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfResetPasswordBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            btnBack.setOnClickListener {
                requireActivity().supportFragmentManager.popBackStackImmediate()
            }

            btnSubmit.setOnClickListener {
                val dialogFragment = DialogFragmentJf(resetData)
                dialogFragment.isCancelable = false
                dialogFragment.show(parentFragmentManager, TAG)
            }
        }
    }

}