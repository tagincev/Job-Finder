package com.aksantara.jobfinder.ui.dashboard.home.search

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.ActivitySearchBinding
import com.aksantara.jobfinder.ui.dashboard.home.filter.FilterActivity

class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initView()

        setViewOpenAreaItem()

    }

    private fun initView() {
        binding.apply {
            btnBack.setOnClickListener {
                finish()
            }

            ivFilter.setOnClickListener {
                setCurrentActivity(FilterActivity())
            }

        }
    }

    private fun setCurrentActivity(activity: Activity) {
        startActivity(Intent(this, activity::class.java))
    }

    private fun setViewOpenAreaItem() {
        binding.apply {
            // Open Area 1
            binding.itemOpenJobs1.apply {
                ivCompany.setImageResource(R.drawable.ic_figma)
                tvPosition.text = "UI Researcher"
                tvLocation.text = "Erlangga st. 12"
                tvCompany.text = "Figma"
                tvJobType.text = "Full Time"
                tvSalary.text = "Start from \$12k/month"
                tvRemote.text = "Remote"
                tvTime.text = "3 days left"
            }
            // Open Area 2
            binding.itemOpenJobs2.apply {
                ivCompany.setImageResource(R.drawable.ic_netflix)
                tvPosition.text = "Senior Developer"
                tvLocation.text = "Jakarta, Indonesia"
                tvCompany.text = "Netflix"
                tvJobType.text = "Full Time"
                tvSalary.text = "Start from \$22k/month"
                tvRemote.text = "On-site"
                tvTime.text = "5 days left"
            }
            // Open Area 3
            binding.itemOpenJobs3.apply {
                ivCompany.setImageResource(R.drawable.ic_meta)
                tvPosition.text = "IOS Developer"
                tvLocation.text = "Jakarta, Indonesia"
                tvCompany.text = "Meta"
                tvJobType.text = "Full Time"
                tvSalary.text = "Start from \$12k/month"
                tvRemote.text = "Remote"
                tvTime.text = "3 days left"
            }
            // Open Area 4
            binding.itemOpenJobs4.apply {
                ivCompany.setImageResource(R.drawable.ic_netflix)
                tvPosition.text = "Junior Developer"
                tvLocation.text = "Jakarta, Indonesia"
                tvCompany.text = "Netflix"
                tvJobType.text = "Full Time"
                tvSalary.text = "Start from \$19k/month"
                tvRemote.text = "On-site"
                tvTime.text = "2 days left"
            }
            // Open Area 5
            binding.itemOpenJobs5.apply {
                ivCompany.setImageResource(R.drawable.ic_meta)
                tvPosition.text = "Java Developer"
                tvLocation.text = "Jakarta, Indonesia"
                tvCompany.text = "Meta"
                tvJobType.text = "Full Time"
                tvSalary.text = "Start from \$12k/month"
                tvRemote.text = "On-site"
                tvTime.text = "1 days left"
            }
        }
    }

}