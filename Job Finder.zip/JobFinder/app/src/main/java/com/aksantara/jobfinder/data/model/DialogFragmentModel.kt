package com.aksantara.jobfinder.data.model

data class DialogFragmentModel(
    val image: Int,
    val title: String,
    val description: String,
    val buttonText: String,
    val toOptionOrLogin: String
)
