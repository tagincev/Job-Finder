package com.aksantara.jobfinder.ui.onboarding

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.ActivityOnboardingBinding
import com.aksantara.jobfinder.ui.login.LoginActivity

class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding

    private val listOnboarding: ArrayList<Onboarding> = arrayListOf(
        Onboarding(
            R.drawable.ic_illust_onboarding,
            "What you seek is always there.",
            "The thing you do, there is always people that look for it, you just have to search for it."
        ),
        Onboarding(
            R.drawable.ic_illust_onboarding2,
            "Opportunity can be what you want.",
            "Experience the good seeking job that will help you guide and make sure you got your job."
        ),
        Onboarding(
            R.drawable.ic_illust_onboarding3,
            "Be organized like never before!",
            "Multitasking, organizing, leading and many more that will upgrade you to the fullest."
        ),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //setting view pager
        setViewPager()

    }

    private fun setViewPager() {
        binding.apply {
            val onboardingPagerAdapter = OnboardingPagerAdapter(listOnboarding)
            viewpager.adapter = onboardingPagerAdapter
            pagerIndicator.attachTo(viewpager)

            viewpager.registerOnPageChangeCallback(
                object : ViewPager2.OnPageChangeCallback() {

                    @RequiresApi(Build.VERSION_CODES.M)
                    override fun onPageSelected(position: Int) {
                        super.onPageSelected(position)
                        when (position) {
                            onboardingPagerAdapter.itemCount - 1 -> {
                                binding.apply {
                                    btnGetStarted.isEnabled = true
                                    btnNext.visibility = View.GONE
                                    tvSkip.visibility = View.GONE
                                    btnGetStarted.visibility = View.VISIBLE
                                    btnGetStarted.setOnClickListener {
                                        val intent = Intent(this@OnboardingActivity, LoginActivity::class.java)
                                        startActivity(intent)
//                                        finish()
                                    }
                                }
                            }
                            onboardingPagerAdapter.itemCount - 2 -> {
                                binding.apply {
                                    btnNext.visibility = View.VISIBLE
                                    tvSkip.visibility = View.VISIBLE
                                    btnGetStarted.visibility = View.GONE
                                    btnNext.setOnClickListener {
                                        viewpager.currentItem = position + 1
                                    }
                                    tvSkip.setOnClickListener {
                                        viewpager.currentItem = onboardingPagerAdapter.itemCount - 1
                                    }
                                }
                            }
                            else -> {
                                binding.apply {
                                    btnNext.visibility = View.VISIBLE
                                    tvSkip.visibility = View.VISIBLE
                                    btnGetStarted.visibility = View.GONE
                                    btnNext.setOnClickListener {
                                        viewpager.currentItem = position + 1
                                    }
                                    tvSkip.setOnClickListener {
                                        viewpager.currentItem = onboardingPagerAdapter.itemCount - 1
                                    }
                                }
                            }
                        }
                    }

                }
            )
        }
    }

}

data class Onboarding(
    val image: Int,
    val title: String,
    val desc: String
)