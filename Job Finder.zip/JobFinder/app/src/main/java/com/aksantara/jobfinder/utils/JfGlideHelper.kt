package com.aksantara.jobfinder.utils

import android.widget.ImageView
import com.bumptech.glide.Glide

object JfGlideHelper {
    fun ImageView.loadImage(url: String?) {
        Glide.with(this)
            .load(url)
            .into(this)
    }
}