package com.aksantara.jobfinder.data.model

data class JfMessageModel(
    val imageAvatar: String,
    val userName: String,
    val messagePreview: String,
    val timeHistory: String,
    val messageCount: Int
)
