package com.aksantara.jobfinder.ui.login.register.option.nationality

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.JfSpinnerModel
import com.aksantara.jobfinder.databinding.FragmentJfNationalityBinding
import com.aksantara.jobfinder.ui.login.register.option.nationality.experience.ExperienceFragment
import com.aksantara.jobfinder.utils.JfSpinnerAdapter

class NationalityFragment : Fragment() {

    private lateinit var binding: FragmentJfNationalityBinding

    private val listCountry = listOf<JfSpinnerModel>(
        JfSpinnerModel(
            R.drawable.ic_jf_indonesia_square,
            "Indonesia"
        ),
        JfSpinnerModel(
            R.drawable.ic_jf_indonesia_square,
            "Poland"
        ),
    )

    private val listDistrict = listOf<JfSpinnerModel>(
        JfSpinnerModel(
            null,
            "Semarang City, Central Java"
        ),
        JfSpinnerModel(
            null,
            "Semarang District, Central Java "
        ),
        JfSpinnerModel(
            null,
            "Kendal District, Central Java "
        ),
        JfSpinnerModel(
            null,
            "Kudus District, Central Java "
        ),
        JfSpinnerModel(
            null,
            "Demak City, Central Java"
        )
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfNationalityBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val adapterCountry = JfSpinnerAdapter(listCountry, requireContext())
        val adapterDistrict = JfSpinnerAdapter(listDistrict, requireContext())

        binding.apply {
            spinnerCountry.adapter = adapterCountry

            spinnerDistrict.adapter = adapterDistrict

            btnBack.setOnClickListener {
                requireActivity().supportFragmentManager.popBackStackImmediate()
            }

            btnNext.setOnClickListener {
                requireActivity().supportFragmentManager.commit {
                    addToBackStack(null)
                    replace(R.id.host_register_activity, ExperienceFragment())
                }
            }
        }
    }
}