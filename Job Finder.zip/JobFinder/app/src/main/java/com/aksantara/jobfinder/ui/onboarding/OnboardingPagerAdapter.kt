package com.aksantara.jobfinder.ui.onboarding

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.aksantara.jobfinder.databinding.LayoutItemOnboardingBinding
class OnboardingPagerAdapter(private val listData: ArrayList<Onboarding>) : RecyclerView.Adapter<OnboardingPagerAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: LayoutItemOnboardingBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Onboarding) {
            binding.apply {
                ivIllustration.setImageResource(item.image)
                tvTitle.text = item.title
                tvDesc.text = item.desc
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): OnboardingPagerAdapter.ViewHolder {
        val binding = LayoutItemOnboardingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: OnboardingPagerAdapter.ViewHolder, position: Int) {
        holder.bind(listData[position])
    }

    override fun getItemCount(): Int {
        return listData.size
    }

}

