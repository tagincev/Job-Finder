package com.aksantara.jobfinder.ui.dashboard.message

import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.annotation.RequiresApi
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.JfMessageModel
import com.aksantara.jobfinder.databinding.FragmentMessageBinding

class MessageFragment : Fragment() {

    private lateinit var binding: FragmentMessageBinding
    private lateinit var adapterMessage: JfMessageAdapter

    private var stateIsFabOpen = false

    private val rotateOpenAnimation: Animation by lazy { AnimationUtils.loadAnimation(requireContext(), R.anim.jf_rotate_open_animation)}
    private val rotateCloseAnimation: Animation by lazy { AnimationUtils.loadAnimation(requireContext(), R.anim.jf_rotate_close_animation)}
    private val fromBottomAnimation: Animation by lazy { AnimationUtils.loadAnimation(requireContext(), R.anim.jf_from_bottom_animation)}
    private val toBottomAnimation: Animation by lazy { AnimationUtils.loadAnimation(requireContext(), R.anim.jf_to_bottom_animation)}
    private val fromRightAnimation: Animation by lazy { AnimationUtils.loadAnimation(requireContext(), R.anim.jf_from_right_animation)}
    private val toRightAnimation: Animation by lazy { AnimationUtils.loadAnimation(requireContext(), R.anim.jf_to_right_animation)}

    private val listMessage = listOf(
        JfMessageModel(
            "https://picsum.photos/258/258",
            "Sarah Payton",
            "Let’s arrange a meeting tomorrow is arrange a meeting tomorrow wi...",
            "2 mins ago",
            3
        ),JfMessageModel(
            "https://picsum.photos/358/358",
            "Jack Ronerc",
            "I thought that your resume is thought that your resume is nice!",
            "3:12 AM",
            1
        ),JfMessageModel(
            "https://picsum.photos/228/228",
            "John Jind",
            "Maybe not so much of that, we not so much of that, we need...",
            "2 hr ago",
            0
        ),JfMessageModel(
            "https://picsum.photos/255/255",
            "Lei Riki",
            "You never gonna believe what never gonna believe what i ...",
            "Yesterday",
            0
        ),JfMessageModel(
            "https://picsum.photos/256/256",
            "Kamdo Tan",
            "Let’s arrange a meeting tomorrow is arrange a meeting tomorrow wi...",
            "2 days ago",
            0
        ),JfMessageModel(
            "https://picsum.photos/257/257",
            "Rias Gemr",
            "Let’s arrange a meeting tomorrow is arrange a meeting tomorrow wi...",
            "3 days ago",
            0
        ),JfMessageModel(
            "https://picsum.photos/257/258",
            "Pion Loka",
            "Let’s arrange a meeting tomorrow is arrange a meeting tomorrow wi...",
            "1 week ago",
            0
        ),JfMessageModel(
            "https://picsum.photos/259/259",
            "Sarah",
            "Let’s arrange a meeting tomorrow is arrange a meeting tomorrow wi...",
            "2 mins ago",
            0
        ),JfMessageModel(
            "https://picsum.photos/250/250",
            "Payton",
            "Let’s arrange a meeting tomorrow is arrange a meeting tomorrow wi...",
            "1 week ago",
            0
        ),JfMessageModel(
            "https://picsum.photos/251/251",
            "Meyla",
            "Let’s arrange a meeting tomorrow is arrange a meeting tomorrow wi...",
            "1 week agoo",
            0
        ),
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentMessageBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapterMessage = JfMessageAdapter(listMessage)

        binding.apply {

            rvMessage.setHasFixedSize(true)
            rvMessage.layoutManager = LinearLayoutManager(requireContext())
            rvMessage.adapter = adapterMessage

            fabAdd.setOnClickListener {
                onAddButtonClicked()
            }

            btnSearch.setOnClickListener {
                etSearch.visibility = View.VISIBLE
                btnBack.visibility = View.VISIBLE
                btnSearch.visibility = View.GONE
                tvTitle.visibility = View.GONE
                etSearch.startAnimation(fromRightAnimation)
                btnBack.startAnimation(fromRightAnimation)
            }

            btnBack.setOnClickListener {
                etSearch.startAnimation(toRightAnimation)
                btnBack.startAnimation(toRightAnimation)
                btnSearch.visibility = View.VISIBLE
                tvTitle.visibility = View.VISIBLE
                etSearch.visibility = View.GONE
                btnBack.visibility = View.GONE
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun onAddButtonClicked() {
        if (stateIsFabOpen) {
            binding.fabAdd.startAnimation(rotateCloseAnimation)
            binding.fabAdd.backgroundTintList = resources.getColorStateList(R.color.colorPrimary500, null)
            binding.fabAdd.imageTintList = resources.getColorStateList(R.color.white, null)
        } else {
            binding.fabAdd.startAnimation(rotateOpenAnimation)
            binding.fabAdd.backgroundTintList = resources.getColorStateList(R.color.white, null)
            binding.fabAdd.imageTintList = resources.getColorStateList(R.color.colorPrimary500, null)
        }

        setVisibility(stateIsFabOpen)
        setAnimation(stateIsFabOpen)
        buttonSetClickable()

        stateIsFabOpen = !stateIsFabOpen
    }


    //Setting call and message buttons visible
    private fun setVisibility(buttonClicked: Boolean) {
        if (!buttonClicked){
            binding.fabCreateMessage.visibility = View.VISIBLE
            binding.fabTrash.visibility = View.VISIBLE
            binding.fabUsers.visibility = View.VISIBLE
        }else{
            binding.fabCreateMessage.visibility = View.INVISIBLE
            binding.fabTrash.visibility = View.INVISIBLE
            binding.fabUsers.visibility = View.INVISIBLE
        }
    }

    //Setting the animation on the buttons
    private fun setAnimation(buttonClicked: Boolean) {
        if (!buttonClicked){
            binding.fabCreateMessage.startAnimation(fromBottomAnimation)
            binding.fabTrash.startAnimation(fromBottomAnimation)
            binding.fabUsers.startAnimation(fromBottomAnimation)
            binding.fabAdd.startAnimation(rotateOpenAnimation)
        }else{
            binding.fabCreateMessage.startAnimation(toBottomAnimation)
            binding.fabTrash.startAnimation(toBottomAnimation)
            binding.fabUsers.startAnimation(toBottomAnimation)
            binding.fabAdd.startAnimation(rotateCloseAnimation)
        }
    }

    //Checking if the add button is clicked
    private fun buttonSetClickable() {
        if (!stateIsFabOpen){
            binding.fabCreateMessage.isClickable = true
            binding.fabTrash.isClickable = true
            binding.fabUsers.isClickable = true
        }else{
            binding.fabCreateMessage.isClickable = false
            binding.fabTrash.isClickable = false
            binding.fabUsers.isClickable = false
        }
    }

}