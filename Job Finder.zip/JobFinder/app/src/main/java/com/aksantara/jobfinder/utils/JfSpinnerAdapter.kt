package com.aksantara.jobfinder.utils

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import com.aksantara.jobfinder.data.model.JfSpinnerModel
import com.aksantara.jobfinder.databinding.ItemJfSpinnerBinding

class JfSpinnerAdapter(private val listData: List<JfSpinnerModel>, private val mContext: Context): BaseAdapter() {
    override fun getCount(): Int {
        return listData.size
    }

    override fun getItem(p0: Int): Any {
        return p0
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    @SuppressLint("ViewHolder")
    override fun getView(i: Int, p1: View?, p2: ViewGroup?): View {
        val binding = ItemJfSpinnerBinding.inflate(LayoutInflater.from(mContext), p2, false)

        binding.apply {
            tvItemSpinner.text = listData[i].textSpinner
            if (listData[i].imageSpinner == null) {
                ivItemSpinner.visibility = View.GONE
            } else {
                listData[i].imageSpinner?.let { ivItemSpinner.setImageResource(it) }
            }
        }

        return binding.root
    }
}