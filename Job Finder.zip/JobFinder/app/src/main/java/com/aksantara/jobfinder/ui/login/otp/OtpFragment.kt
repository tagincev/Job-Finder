package com.aksantara.jobfinder.ui.login.otp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.DialogFragmentModel
import com.aksantara.jobfinder.databinding.FragmentOtpBinding
import com.aksantara.jobfinder.ui.login.dialogfragment.DialogFragmentJf
import com.aksantara.jobfinder.ui.login.forgotpassword.resetpassword.ResetPasswordFragment
import com.aksantara.jobfinder.ui.login.register.option.OptionFragment

class OtpFragment : Fragment() {

    private lateinit var binding: FragmentOtpBinding

    private val registerData = DialogFragmentModel(
        R.drawable.ic_jf_mail_check,
        "Your Account Is Activated",
        "Now you can setup your profile account! Head to the next page to get started.",
        "Take Me There!",
        OptionFragment.OPTION_TEXT
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentOtpBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            btnBack.setOnClickListener { activity?.onBackPressed() }

            btnSubmit.setOnClickListener {
                //show dialog
                when (requireArguments().getString(OTP_TEXT, "")) {
                    "register" -> {
                        val dialogFragment = DialogFragmentJf(registerData)
                        dialogFragment.isCancelable = false
                        dialogFragment.show(parentFragmentManager, TAG)
                    }
                    "reset" -> {
                        requireActivity().supportFragmentManager.commit {
                            replace(R.id.host_forgot_password_activity, ResetPasswordFragment())
                            addToBackStack(null)
                        }
                    }
                }
            }
        }
    }

    companion object {
        const val OTP_TEXT = "otp_text"
        private val TAG = OtpFragment::class.simpleName
    }

}