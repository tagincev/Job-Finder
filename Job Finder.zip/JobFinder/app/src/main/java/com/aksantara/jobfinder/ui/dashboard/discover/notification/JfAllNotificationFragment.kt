package com.aksantara.jobfinder.ui.dashboard.discover.notification

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.aksantara.jobfinder.databinding.FragmentJfAllNotificationBinding
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage

class JfAllNotificationFragment : Fragment() {

    private lateinit var binding: FragmentJfAllNotificationBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfAllNotificationBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            //iv company
            item1.ivCompany.loadImage("https://picsum.photos/253/254")
            item2.ivCompany.loadImage("https://picsum.photos/253/255")
            item3.ivCompany.loadImage("https://picsum.photos/253/255")
            item4.ivCompany.loadImage("https://picsum.photos/253/256")
            item5.ivCompany.loadImage("https://picsum.photos/253/256")

            //tv title
            item2.tvTitle.text = "Your application is being reviewed!"
            item3.tvTitle.text = "Your application turned down!"
            item4.tvTitle.text = "Your application turned down!"
            item5.tvTitle.text = "Your application turned down!"

            //tv desc
            item2.tvDesc.text = "Your application to Bananana is being reviewed! Stand by for more info!"
            item3.tvDesc.text = "Your application to Bananana is turned down! Don’t worry, there is more vacancy coming!"
            item4.tvDesc.text = "Your application to Ae Corporation is turned down! Don’t worry, there is more vacancy coming!"
            item5.tvDesc.text = "Your application to Ae Corporation is turned down! Don’t worry, there is more vacancy coming!"

        }
    }

}