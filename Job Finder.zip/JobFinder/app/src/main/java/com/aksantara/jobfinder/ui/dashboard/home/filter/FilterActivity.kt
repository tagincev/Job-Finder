package com.aksantara.jobfinder.ui.dashboard.home.filter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.aksantara.jobfinder.databinding.ActivityFilterBinding

class FilterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFilterBinding
    private var experienceState = false
    private var locationState = false
    private var industryState = false
    private var jobTitleState = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFilterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            btnBack.setOnClickListener {
                finish()
            }

            binding.apply {
                btnBack.setOnClickListener {
                    finish()
                }

                btnApply.setOnClickListener {
                    finish()
                }

                //initial view
                rbMostRecent.isChecked = true
                rbAny.isChecked = true
                resetAndApplyHandler()

                //Sort by
                rbMostRecent.setOnClickListener { sortByHandler(1) }
                rbMostRelevant.setOnClickListener { sortByHandler(2) }

                //Date posted
                rbAny.setOnClickListener { datePostedHandler(1) }
                rb24Hours.setOnClickListener { datePostedHandler(2) }
                rb7Days.setOnClickListener { datePostedHandler(3) }
                rbPastMonth.setOnClickListener { datePostedHandler(4) }

                //Experience level
                cbInternship.setOnClickListener { experienceLevelHandler() }
                cbEntryLevel.setOnClickListener { experienceLevelHandler() }
                cbAssociate.setOnClickListener { experienceLevelHandler() }
                cbMidSeniorLevel.setOnClickListener { experienceLevelHandler() }
                cbDirector.setOnClickListener { experienceLevelHandler() }
                cbExecutive.setOnClickListener { experienceLevelHandler() }

                //Location
                cbSemarang.setOnClickListener { locationHandler() }
                cbJakarta.setOnClickListener { locationHandler() }
                cbBandung.setOnClickListener { locationHandler() }
                cbMalang.setOnClickListener { locationHandler() }

                //Industry
                cbItService.setOnClickListener { industryHandler() }
                cbFinancialServices.setOnClickListener { industryHandler() }
                cbSoftwareDev.setOnClickListener { industryHandler() }
                cbFoodServices.setOnClickListener { industryHandler() }

                //Reset Button
                btnReset.setOnClickListener {
                    resetFilter()
                }
            }

        }
    }

    private fun industryHandler() {
        binding.apply {
            if (cbItService.isChecked ||
                cbFinancialServices.isChecked ||
                cbSoftwareDev.isChecked ||
                cbFoodServices.isChecked
            ) {
                industryState = true
            }

            if (!cbItService.isChecked &&
                !cbFinancialServices.isChecked &&
                !cbSoftwareDev.isChecked &&
                !cbFoodServices.isChecked
            ) {
                industryState = false
            }
        }
        resetAndApplyHandler()
    }

    private fun locationHandler() {
        binding.apply {
            if (cbSemarang.isChecked ||
                cbJakarta.isChecked ||
                cbBandung.isChecked ||
                cbMalang.isChecked
            ) {
                locationState = true
            }

            if (!cbSemarang.isChecked &&
                !cbJakarta.isChecked &&
                !cbBandung.isChecked &&
                !cbMalang.isChecked
            ) {
                locationState = false
            }
        }
        resetAndApplyHandler()
    }

    private fun experienceLevelHandler() {
        binding.apply {
            if (cbInternship.isChecked ||
                cbEntryLevel.isChecked ||
                cbAssociate.isChecked ||
                cbMidSeniorLevel.isChecked ||
                cbDirector.isChecked ||
                cbExecutive.isChecked
            ) {
                experienceState = true
            }

            if (
                !cbInternship.isChecked &&
                !cbEntryLevel.isChecked &&
                !cbAssociate.isChecked &&
                !cbMidSeniorLevel.isChecked &&
                !cbDirector.isChecked &&
                !cbExecutive.isChecked
            ) {
                experienceState = false
            }
        }
        resetAndApplyHandler()
    }

    private fun datePostedHandler(i: Int) {
        binding.apply {
            when (i) {
                1 -> {
                    rbAny.isChecked = true
                    rb24Hours.isChecked = false
                    rb7Days.isChecked = false
                    rbPastMonth.isChecked = false
                }
                2 -> {
                    rbAny.isChecked = false
                    rb24Hours.isChecked = true
                    rb7Days.isChecked = false
                    rbPastMonth.isChecked = false
                }
                3 -> {
                    rbAny.isChecked = false
                    rb24Hours.isChecked = false
                    rb7Days.isChecked = true
                    rbPastMonth.isChecked = false
                }
                4 -> {
                    rbAny.isChecked = false
                    rb24Hours.isChecked = false
                    rb7Days.isChecked = false
                    rbPastMonth.isChecked = true
                }
            }
        }
        resetAndApplyHandler()
    }

    private fun sortByHandler(i: Int) {
        binding.apply {
            when (i) {
                1 -> {
                    rbMostRecent.isChecked = true
                    rbMostRelevant.isChecked = false
                }
                2 -> {
                    rbMostRecent.isChecked = false
                    rbMostRelevant.isChecked = true
                }
            }
        }
        resetAndApplyHandler()
    }

    private fun resetAndApplyHandler() {
        binding.apply {
            btnReset.isEnabled =
                !(rbAny.isChecked
                        && rbMostRecent.isChecked
                        && !experienceState
                        && !locationState
                        && !industryState
                        && !jobTitleState)
            btnApply.isEnabled =
                !(rbAny.isChecked
                        && rbMostRecent.isChecked
                        && !experienceState
                        && !locationState
                        && !industryState
                        && !jobTitleState)
        }
    }

    private fun resetFilter() {
        binding.apply {
            //Sort by
            rbMostRecent.isChecked = true
            rbMostRelevant.isChecked = false

            //Date posted
            rbAny.isChecked = true
            rb24Hours.isChecked = false
            rb7Days.isChecked = false
            rbPastMonth.isChecked = false

            //Experience level
            cbInternship.isChecked = false
            cbEntryLevel.isChecked = false
            cbAssociate.isChecked = false
            cbMidSeniorLevel.isChecked = false
            cbDirector.isChecked = false
            cbExecutive.isChecked = false

            //Location
            cbSemarang.isChecked = false
            cbJakarta.isChecked = false
            cbBandung.isChecked = false
            cbMalang.isChecked = false

            //Industry
            cbItService.isChecked = false
            cbFinancialServices.isChecked = false
            cbSoftwareDev.isChecked = false
            cbFoodServices.isChecked = false

            btnReset.isEnabled = false
            btnApply.isEnabled = false
        }
    }

}