package com.aksantara.jobfinder.ui.detail.detailcompany.availablejob

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.aksantara.jobfinder.databinding.FragmentJfAvailableJobsBinding

class JfAvailableJobsFragment : Fragment() {

    private lateinit var binding: FragmentJfAvailableJobsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfAvailableJobsBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            //item2
            item2.tvPosition.text = "Graphic Designer"
            item2.tvSalary.text = "\$15-20K per year"
            item2.tvJobType1.text = "Part-time"

            //item3
            item2.tvPosition.text = "Content Creator"
            item2.tvSalary.text = "\$12K per project"
            item2.tvJobType1.text = "Contract"

        }
    }

}