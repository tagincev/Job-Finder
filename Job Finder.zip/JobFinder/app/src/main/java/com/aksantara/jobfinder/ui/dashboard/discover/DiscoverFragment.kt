package com.aksantara.jobfinder.ui.dashboard.discover

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import androidx.fragment.app.commit
import androidx.viewpager2.widget.ViewPager2
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.JfSponsoredVacancy
import com.aksantara.jobfinder.databinding.FragmentDiscoverBinding
import com.aksantara.jobfinder.ui.dashboard.discover.jobcategory.JobCategoryActivity
import com.aksantara.jobfinder.ui.dashboard.discover.notification.NotificationActivity
import com.aksantara.jobfinder.ui.dashboard.home.filter.FilterActivity
import com.aksantara.jobfinder.ui.dashboard.home.search.SearchActivity
import com.aksantara.jobfinder.ui.detail.detailcompany.DetailCompanyActivity
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage

class DiscoverFragment : Fragment() {

    private lateinit var binding: FragmentDiscoverBinding

    private val sponsoredVacAdapter = JfSponsoredVacAdapter(
        listOf(
            JfSponsoredVacancy(
                "https://picsum.photos/283/283",
                "https://picsum.photos/276/283",
                "Orange Just Co.",
                "Jakarta, Indonesia",
                "UI/UX Designer",
                "Full-time",
                "\$35-50K per year",
                "3 days left"
            ),
            JfSponsoredVacancy(
                "https://picsum.photos/383/383",
                "https://picsum.photos/276/276",
                "Orange Just Co.",
                "Jakarta, Indonesia",
                "UI/UX Designer",
                "Full-time",
                "\$35-50K per year",
                "3 days left"
            ),
            JfSponsoredVacancy(
                "https://picsum.photos/483/483",
                "https://picsum.photos/283/276",
                "Orange Just Co.",
                "Jakarta, Indonesia",
                "UI/UX Designer",
                "Full-time",
                "\$35-50K per year",
                "3 days left"
            ),
            JfSponsoredVacancy(
                "https://picsum.photos/583/583",
                "https://picsum.photos/283/276",
                "Orange Just Co.",
                "Jakarta, Indonesia",
                "UI/UX Designer",
                "Full-time",
                "\$35-50K per year",
                "3 days left"
            ),
            JfSponsoredVacancy(
                "https://picsum.photos/683/683",
                "https://picsum.photos/276/283",
                "Orange Just Co.",
                "Jakarta, Indonesia",
                "UI/UX Designer",
                "Full-time",
                "\$35-50K per year",
                "3 days left"
            ),
        ),
    )

    private val indicators = arrayOfNulls<ImageView>(5)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentDiscoverBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupOnboardingIndicator()
        setCurrentIndicator(0)
        setViewpagerAdapter()

        binding.apply {
            //most viewed
            itemMostViewed1.apply {
                ivBackground.loadImage("https://picsum.photos/623/623")
                ivCompany.loadImage("https://picsum.photos/483/483")
                ivEmployee1.loadImage("https://picsum.photos/363/363")
                ivEmployee2.loadImage("https://picsum.photos/373/373")
                ivEmployee3.loadImage("https://picsum.photos/383/383")
                tvCompany.text = "PT. Marga Makmur"
                tvLocation.text = "Bandung, Indonesia"
                tvRating.text = "5 Ratings"
                tvViewer.text = "90k Views"
            }

            itemMostViewed2.apply {
                ivBackground.loadImage("https://picsum.photos/629/629")
                ivCompany.loadImage("https://picsum.photos/489/489")
                ivEmployee1.loadImage("https://picsum.photos/386/386")
                ivEmployee2.loadImage("https://picsum.photos/387/387")
                ivEmployee3.loadImage("https://picsum.photos/388/388")
            }

            //category action
            categoryAction()

            //click company
            itemMostViewed1.root.setOnClickListener {
                setCurrentActivity(DetailCompanyActivity())
            }

            itemMostViewed2.root.setOnClickListener {
                setCurrentActivity(DetailCompanyActivity())
            }

            linearSearch.setOnClickListener {
                setCurrentActivity(SearchActivity())
            }

            ivFilter.setOnClickListener {
                setCurrentActivity(FilterActivity())
            }

            //notification
            btnNotification.setOnClickListener {
                setCurrentActivity(NotificationActivity())
            }
        }
    }

    private fun setCurrentActivity(activity: Activity) {
        startActivity(Intent(requireActivity(), activity::class.java))
    }

    private fun categoryAction() {
        binding.apply {
            cvArt.setOnClickListener { goingToJobCategoryActivity() }
            cvComposer.setOnClickListener { goingToJobCategoryActivity() }
            cvHrd.setOnClickListener { goingToJobCategoryActivity() }
            cvBigData.setOnClickListener { goingToJobCategoryActivity() }
            cvGamer.setOnClickListener { goingToJobCategoryActivity() }
            cvFinance.setOnClickListener { goingToJobCategoryActivity() }
            cvPhotographer.setOnClickListener { goingToJobCategoryActivity() }
            cvProgrammer.setOnClickListener { goingToJobCategoryActivity() }
            cvWriter.setOnClickListener { goingToJobCategoryActivity() }
        }
    }

    private fun goingToJobCategoryActivity() {
        val intent = Intent(requireContext(), JobCategoryActivity::class.java)
        startActivity(intent)
    }

    private fun setupOnboardingIndicator() {
        val layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        layoutParams.setMargins(8, 0, 8, 0)
        for (i in indicators.indices) {
            indicators[i] = ImageView(requireContext().applicationContext)
            indicators[i]!!.setImageDrawable(
                ContextCompat.getDrawable(
                    requireContext().applicationContext,
                    R.drawable.ic_jf_sponsored_vac_indicator_inactive
                )
            )
            indicators[i]!!.layoutParams = layoutParams
            binding.layoutIndicatorSponsored.addView(indicators[i])
        }
    }

    private fun setViewpagerAdapter() {

        binding.viewPagerSponsored.adapter = sponsoredVacAdapter

        binding.viewPagerSponsored.registerOnPageChangeCallback(
            object : ViewPager2.OnPageChangeCallback() {

                override fun onPageSelected(position: Int) {
                    super.onPageSelected(position)
                    setCurrentIndicator(position)
//                    when (position) {
//                        sponsoredVacAdapter.itemCount - 1 -> {
//                            binding.apply {
//                                btnOnboardingAction.text = getString(R.string.mb_get_started)
//                                btnOnboardingAction.setOnClickListener {
//                                    val intent =
//                                        Intent(
//                                            this@MbOnboardingActivity,
//                                            MbLoginActivity::class.java
//                                        )
//                                    startActivity(intent)
//                                    finish()
//                                }
//                                tvSkip.visibility = View.INVISIBLE
//                                btnBack.visibility = View.VISIBLE
//                                btnBack.setOnClickListener {
//                                    onBoardingViewPager.currentItem = position - 1
//                                }
//                            }
//                        }
//                        sponsoredVacAdapter.itemCount - 2 -> {
//                            binding.apply {
//                                btnOnboardingAction.text = getString(R.string.mb_proceed)
//                                btnOnboardingAction.setOnClickListener {
//                                    onBoardingViewPager.currentItem = position + 1
//                                }
//                                tvSkip.visibility = View.VISIBLE
//                                tvSkip.setOnClickListener{
//                                    onBoardingViewPager.currentItem = position + 1
//                                }
//                                btnBack.visibility = View.VISIBLE
//                                btnBack.setOnClickListener {
//                                    onBoardingViewPager.currentItem = position - 1
//                                }
//                            }
//                        }
//                        else -> {
//                            binding.apply {
//                                btnOnboardingAction.text = getString(R.string.mb_proceed)
//                                btnOnboardingAction.setOnClickListener {
//                                    onBoardingViewPager.currentItem = position + 1
//                                }
//                                tvSkip.visibility = View.VISIBLE
//                                tvSkip.setOnClickListener{
//                                    onBoardingViewPager.currentItem = position + 2
//                                }
//                                btnBack.visibility = View.INVISIBLE
//                            }
//                        }
//                    }
                }

            })

    }

    private fun setCurrentIndicator(index: Int) {

        for (i in indicators.indices) {
            val imageView: ImageView = binding.layoutIndicatorSponsored.getChildAt(i) as ImageView
            if (i == index) {
                imageView.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext().applicationContext,
                        R.drawable.ic_jf_sponsored_vac_indicator_active
                    )
                )
            } else {
                imageView.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext().applicationContext,
                        R.drawable.ic_jf_sponsored_vac_indicator_inactive
                    )
                )
            }
        }
    }

}