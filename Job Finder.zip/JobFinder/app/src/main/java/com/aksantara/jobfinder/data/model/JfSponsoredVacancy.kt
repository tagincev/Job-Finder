package com.aksantara.jobfinder.data.model

data class JfSponsoredVacancy(
    val backdrop: String,
    val logoCompany: String,
    val company: String,
    val location: String,
    val position: String,
    val jobType: String,
    val salary: String,
    val timeLeft: String
)
