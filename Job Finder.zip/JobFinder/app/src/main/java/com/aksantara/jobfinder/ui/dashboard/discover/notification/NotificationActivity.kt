package com.aksantara.jobfinder.ui.dashboard.discover.notification

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.OnBackPressedDispatcher
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.ActivityNotificationBinding
import com.google.android.material.tabs.TabLayoutMediator

class NotificationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationBinding
    private lateinit var adapter: JfNotificationPagerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            btnBack.setOnClickListener {
                onBackPressedDispatcher.onBackPressed()
            }

            viewPager2.adapter = JfNotificationPagerAdapter(this@NotificationActivity)
        }

        TabLayoutMediator(binding.tabLayout, binding.viewPager2) { tab, position ->
            tab.text = when (position) {
                0 -> "All"
                1 -> "Applied"
                2 -> "Reviewed"
                3 -> "Rejected"
                else -> ""
            }
        }.attach()
    }
}