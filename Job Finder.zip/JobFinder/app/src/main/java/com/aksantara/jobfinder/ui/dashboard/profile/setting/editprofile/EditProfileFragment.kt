package com.aksantara.jobfinder.ui.dashboard.profile.setting.editprofile

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.JfSpinnerModel
import com.aksantara.jobfinder.databinding.FragmentEditProfileBinding
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage
import com.aksantara.jobfinder.utils.JfSpinnerAdapter

class EditProfileFragment : Fragment() {

    private lateinit var binding: FragmentEditProfileBinding

    private val listEmploymentType = listOf(
        JfSpinnerModel(
            null,
            "Full-time"
        ),
        JfSpinnerModel(
            null,
            "Part-time"
        ),
        JfSpinnerModel(
            null,
            "Intern"
        ),
    )

    private val listExperience = listOf(
        JfSpinnerModel(
            null,
            "1-2 Years"
        ),
        JfSpinnerModel(
            null,
            "3-4 Years"
        ),
        JfSpinnerModel(
            null,
            "5 Years Above"
        ),
    )


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentEditProfileBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            ivProfile.loadImage("https://picsum.photos/254/254")

            spinnerEmployeeType.adapter = JfSpinnerAdapter(listEmploymentType, requireContext())

            spinnerExperience.adapter = JfSpinnerAdapter(listExperience, requireContext())

            btnBack.setOnClickListener {
                requireActivity().supportFragmentManager.popBackStackImmediate()
            }

            btnSave.setOnClickListener {
                Toast.makeText(requireContext(), "Saved", Toast.LENGTH_SHORT).show()
                requireActivity().supportFragmentManager.popBackStackImmediate()
            }
        }

    }

}