package com.aksantara.jobfinder.ui.login.register.option.nationality.experience

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.JfSpinnerModel
import com.aksantara.jobfinder.databinding.FragmentJfExperienceBinding
import com.aksantara.jobfinder.ui.login.register.option.nationality.experience.education.EducationFragment
import com.aksantara.jobfinder.utils.JfSpinnerAdapter

class ExperienceFragment : Fragment() {

    private lateinit var binding: FragmentJfExperienceBinding

    private val listEmploymentType = listOf(
        JfSpinnerModel(
            null,
            "Full-time"
        ),
        JfSpinnerModel(
            null,
            "Part-time"
        ),
        JfSpinnerModel(
            null,
            "Intern"
        ),
    )

    private val listExperience = listOf(
        JfSpinnerModel(
            null,
            "1-2 Years"
        ),
        JfSpinnerModel(
            null,
            "3-4 Years"
        ),
        JfSpinnerModel(
            null,
            "5 Years Above"
        ),
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfExperienceBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            spinnerEmployeeType.adapter = JfSpinnerAdapter(listEmploymentType, requireContext())

            spinnerExperience.adapter = JfSpinnerAdapter(listExperience, requireContext())

            btnBack.setOnClickListener {
                requireActivity().supportFragmentManager.popBackStackImmediate()
            }

            btnNext.setOnClickListener {
                requireActivity().supportFragmentManager.commit {
                    replace(R.id.host_register_activity, EducationFragment())
                    addToBackStack(null)
                }
            }

            itemSkill2.tvSkill.text = "Photoshop"
            itemSkill3.tvSkill.text = "Figma"
        }
    }
}