package com.aksantara.jobfinder.ui.dashboard.message.roomchat

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.aksantara.jobfinder.databinding.FragmentJfRoomChatBinding
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage

class JfRoomChatFragment : Fragment() {

    private lateinit var binding: FragmentJfRoomChatBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfRoomChatBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            btnBack.setOnClickListener {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }

            ivProfile.loadImage("https://picsum.photos/258/258")
            ivAvatar2.loadImage("https://picsum.photos/258/258")
            ivAvatar5.loadImage("https://picsum.photos/258/258")

            ivAvatar3.loadImage("https://picsum.photos/258/268")
            ivAvatar4.loadImage("https://picsum.photos/258/268")
            ivAvatar6.loadImage("https://picsum.photos/258/268")
        }
    }

}