package com.aksantara.jobfinder.ui.dashboard.home

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.FragmentHomeBinding
import com.aksantara.jobfinder.ui.dashboard.discover.notification.NotificationActivity
import com.aksantara.jobfinder.ui.dashboard.home.filter.FilterActivity
import com.aksantara.jobfinder.ui.dashboard.home.openarea.OpenAreaActivity
import com.aksantara.jobfinder.ui.dashboard.home.search.SearchActivity
import com.aksantara.jobfinder.ui.detail.detailjob.DetailJobActivity

class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            linearSearch.setOnClickListener {
                setCurrentActivity(SearchActivity())
            }

            ivFilter.setOnClickListener {
                setCurrentActivity(FilterActivity())
            }

            tvSeeAllArea.setOnClickListener {
                setCurrentActivity(OpenAreaActivity())
            }

            ivNotification.setOnClickListener {
                setCurrentActivity(NotificationActivity())
            }
        }

        setViewRecommendedItem()

        setViewOpenAreaItem()

    }

    private fun setCurrentActivity(activity: Activity) {
        startActivity(Intent(requireActivity(), activity::class.java))
    }

    private fun setViewOpenAreaItem() {
        binding.apply {
            // Open Area 1
            itemOpenJobs1.apply {
                ivCompany.setImageResource(R.drawable.ic_figma)
                tvPosition.text = "UI Researcher"
                tvLocation.text = "Erlangga st. 12"
                tvCompany.text = "Figma"
                tvJobType.text = "Full Time"
                tvSalary.text = "\$12k/month"
                tvRemote.text = "Remote"
                tvTime.text = "3 days left"
            }

            itemOpenJobs1.root.setOnClickListener {
                setCurrentActivity(DetailJobActivity())
            }

            // Open Area 2
            itemOpenJobs2.apply {
                ivCompany.setImageResource(R.drawable.ic_netflix)
                tvPosition.text = "Senior Developer"
                tvLocation.text = "Jakarta, Indonesia"
                tvCompany.text = "Netflix"
                tvJobType.text = "Full Time"
                tvSalary.text = "\$22k/month"
                tvRemote.text = "On-site"
                tvTime.text = "5 days left"
            }

            itemOpenJobs2.root.setOnClickListener {
                setCurrentActivity(DetailJobActivity())
            }

            // Open Area 3
            itemOpenJobs3.apply {
                ivCompany.setImageResource(R.drawable.ic_meta)
                tvPosition.text = "IOS Developer"
                tvLocation.text = "Jakarta, Indonesia"
                tvCompany.text = "Meta"
                tvJobType.text = "Full Time"
                tvSalary.text = "\$12k/month"
                tvRemote.text = "Remote"
                tvTime.text = "3 days left"
            }

            itemOpenJobs3.root.setOnClickListener {
                setCurrentActivity(DetailJobActivity())
            }

        }
    }

    private fun setViewRecommendedItem() {
        binding.apply {
            // Recommended 1
            binding.itemRecommended1.apply {
                ivCompany.setImageResource(R.drawable.ic_google_ads)
                tvCompanyName.text = "Google Ads"
                tvLocation.text = "Jakarta, Indonesia"
                tvSalary.text = "Start from \$12k/month"
                tvTime.text = "Until 28 Dec, 2022"
            }

            itemRecommended1.root.setOnClickListener {
                setCurrentActivity(DetailJobActivity())
            }

            // Recommended 2
            binding.itemRecommended2.apply {
                ivCompany.setImageResource(R.drawable.ic_qiwi)
                tvCompanyName.text = "Qiwi"
                tvLocation.text = "Jakarta, Indonesia"
                tvSalary.text = "Start from \$8k/month"
                tvTime.text = "Until 17 Dec, 2022"
            }

            itemRecommended2.root.setOnClickListener {
                setCurrentActivity(DetailJobActivity())
            }

            // Recommended 3
            binding.itemRecommended3.apply {
                ivCompany.setImageResource(R.drawable.ic_meta)
                tvCompanyName.text = "Meta"
                tvLocation.text = "Jakarta, Indonesia"
                tvSalary.text = "Start from \$12k/month"
                tvTime.text = "Until 18 Jul, 2023"
            }

            itemRecommended3.root.setOnClickListener {
                setCurrentActivity(DetailJobActivity())
            }

        }
    }

}