package com.aksantara.jobfinder.ui.dashboard.discover.notification

import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

class JfNotificationPagerAdapter(activity: AppCompatActivity) : FragmentStateAdapter(activity){
    override fun getItemCount(): Int = 4

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> JfAllNotificationFragment()
            1 -> JfAppliedFragment()
            2 -> JfAllNotificationFragment()
            3 -> JfAppliedFragment()
            else -> JfAllNotificationFragment()
        }
    }
}