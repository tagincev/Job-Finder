package com.aksantara.jobfinder.ui.dashboard.discover

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commit
import androidx.recyclerview.widget.RecyclerView
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.JfSponsoredVacancy
import com.aksantara.jobfinder.databinding.ItemJfSponsoredBinding
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage


class JfSponsoredVacAdapter(private val sponsoredDataList: List<JfSponsoredVacancy>) : RecyclerView.Adapter<JfSponsoredVacAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: ItemJfSponsoredBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(sponsoredData: JfSponsoredVacancy) {

            //to resolve Pages must fill the whole ViewPager2 (use match_parent)
            binding.root.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT)

            with(binding) {
                ivBackdrop.loadImage(sponsoredData.backdrop)
                ivCompany.loadImage(sponsoredData.logoCompany)
                tvPosition.text = sponsoredData.position
                tvSalary.text = sponsoredData.salary
                tvJobType.text = sponsoredData.jobType
                tvCompany.text = sponsoredData.company
            }

            binding.linearCompany.setOnClickListener {
//                setCurrentFragmentFromAdapter(JfDetailCompanyFragment())
            }

            itemView.setOnClickListener {
//                setCurrentFragmentFromAdapter(JfDetailJobFragment())
            }
        }

        private fun setCurrentFragmentFromAdapter(fragment: Fragment) {
            (itemView.context as FragmentActivity).supportFragmentManager.commit {
//                replace(R.id.host_activity_main, fragment)
                addToBackStack(null)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemJfSponsoredBinding.inflate(LayoutInflater.from(parent.context))
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(sponsoredDataList[position])
    }

    override fun getItemCount(): Int {
        return sponsoredDataList.size
    }

}