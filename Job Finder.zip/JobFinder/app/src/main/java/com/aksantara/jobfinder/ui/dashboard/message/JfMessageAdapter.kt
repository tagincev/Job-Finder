package com.aksantara.jobfinder.ui.dashboard.message

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.aksantara.jobfinder.data.model.JfMessageModel
import com.aksantara.jobfinder.databinding.ItemJfMessageBinding
import com.aksantara.jobfinder.ui.dashboard.message.roomchat.RoomChatActivity
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage

class JfMessageAdapter(private val listMessage: List<JfMessageModel>) : RecyclerView.Adapter<JfMessageAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemJfMessageBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(item: JfMessageModel) {
            binding.apply {
                ivAvatar.loadImage(item.imageAvatar)
                tvUsername.text = item.userName
                tvMessagePreview.text = item.messagePreview
                tvTimeHistory.text = item.timeHistory

                if (item.messageCount != 0) {
                    tvMessageCount.text = item.messageCount.toString()
                } else {
                    cvMessagesCount.visibility = View.GONE
                }

                //handling clicked item
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, RoomChatActivity::class.java)
                    itemView.context.startActivity(intent)
                }
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JfMessageAdapter.ViewHolder {
        val binding = ItemJfMessageBinding.inflate(LayoutInflater.from(parent.context))
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JfMessageAdapter.ViewHolder, position: Int) {
        holder.bind(listMessage[position])
    }

    override fun getItemCount(): Int {
        return listMessage.size
    }
}