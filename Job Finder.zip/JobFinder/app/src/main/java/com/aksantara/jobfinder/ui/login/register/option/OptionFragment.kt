package com.aksantara.jobfinder.ui.login.register.option

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.FragmentJfOptionBinding
import com.aksantara.jobfinder.ui.login.register.option.nationality.NationalityFragment

class OptionFragment : Fragment() {

    private lateinit var binding: FragmentJfOptionBinding

    companion object {
        const val OPTION_TEXT = "option_text"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfOptionBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            itemForJob.setOnClickListener { itemHandler(0) }

            itemForEmployee.setOnClickListener { itemHandler(1) }

            btnNext.setOnClickListener {
                requireActivity().supportFragmentManager.commit {
                    addToBackStack(null)
                    replace(R.id.host_register_activity, NationalityFragment())
                }
            }
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @RequiresApi(Build.VERSION_CODES.M)
    private fun itemHandler(i: Int) {
        val configuration: Configuration = resources.configuration

        binding.apply {
            if (configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK === Configuration.UI_MODE_NIGHT_YES) {
                // Dark mode is enabled
                // Add your logic for dark mode here
                when (i) {
                    0 -> {
                        cvForJob.backgroundTintList = resources.getColorStateList(R.color.colorPrimary500, null)
                        itemForJob.background = resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                        cvForEmployee.backgroundTintList = resources.getColorStateList(R.color.colorNeutral400, null)
                        itemForEmployee.background = resources.getDrawable(R.drawable.bg_jf_outline_neutral400, null)
                        ivForJob.setImageResource(R.drawable.ic_jf_briefcase_white)
                        ivForEmployee.setImageResource(R.drawable.ic_jf_for_employee_grey)
                        // set text style
                        tvForJob.setTextAppearance(R.style.Txt_Bold16)
                        tvForJob.setTextColor(resources.getColor(R.color.white, null))
                        tvForEmployee.setTextAppearance(R.style.Txt_Medium16)
                        tvForEmployee.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                    }
                    1 -> {
                        cvForJob.backgroundTintList = resources.getColorStateList(R.color.colorNeutral400, null)
                        itemForJob.background = resources.getDrawable(R.drawable.bg_jf_outline_neutral400, null)
                        cvForEmployee.backgroundTintList = resources.getColorStateList(R.color.colorPrimary500, null)
                        itemForEmployee.background = resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                        ivForJob.setImageResource(R.drawable.ic_jf_briefcase_grey)
                        ivForEmployee.setImageResource(R.drawable.ic_jf_for_employee_white)
                        // set text style
                        tvForJob.setTextAppearance(R.style.Txt_Medium16)
                        tvForJob.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                        tvForEmployee.setTextAppearance(R.style.Txt_Bold16)
                        tvForEmployee.setTextColor(resources.getColor(R.color.white, null))
                    }
                }
            } else {
                // Dark mode is not enabled
                // Add your logic for light mode here
                when (i) {
                    0 -> {
                        cvForJob.backgroundTintList = resources.getColorStateList(R.color.colorPrimary500, null)
                        itemForJob.background = resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                        cvForEmployee.backgroundTintList = resources.getColorStateList(R.color.colorNeutral200, null)
                        itemForEmployee.background = resources.getDrawable(R.color.white, null)
                        ivForJob.setImageResource(R.drawable.ic_jf_briefcase_white)
                        ivForEmployee.setImageResource(R.drawable.ic_jf_for_employee_grey)
                        // set text style
                        tvForJob.setTextAppearance(R.style.Txt_Bold16)
                        tvForJob.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                        tvForEmployee.setTextAppearance(R.style.Txt_Medium16)
                        tvForEmployee.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                    }
                    1 -> {
                        cvForJob.backgroundTintList = resources.getColorStateList(R.color.colorNeutral200, null)
                        itemForJob.background = resources.getDrawable(R.color.white, null)
                        cvForEmployee.backgroundTintList = resources.getColorStateList(R.color.colorPrimary500, null)
                        itemForEmployee.background = resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                        ivForJob.setImageResource(R.drawable.ic_jf_briefcase_grey)
                        ivForEmployee.setImageResource(R.drawable.ic_jf_for_employee_white)
                        // set text style
                        tvForJob.setTextAppearance(R.style.Txt_Medium16)
                        tvForJob.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                        tvForEmployee.setTextAppearance(R.style.Txt_Bold16)
                        tvForEmployee.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                    }
                }
            }
        }
    }
}