package com.aksantara.jobfinder.ui.dashboard

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.ActivityDashboardBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.host_fragment_activity_dashboard) as NavHostFragment
        val navController = navHostFragment.navController

        findViewById<BottomNavigationView>(R.id.bottom_navigation)
            .setupWithNavController(navController)
    }

    override fun onBackPressed() {
        val countStack = supportFragmentManager.backStackEntryCount
        if (countStack == 0) {
            super.onBackPressed()
        } else if (countStack == 1) {
            supportFragmentManager.popBackStackImmediate()
            binding.bottomNavigation.visibility = View.VISIBLE
        } else {
            supportFragmentManager.popBackStackImmediate()
        }
    }
}