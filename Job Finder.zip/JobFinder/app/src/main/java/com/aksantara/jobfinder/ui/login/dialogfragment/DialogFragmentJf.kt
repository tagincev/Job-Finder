package com.aksantara.jobfinder.ui.login.dialogfragment

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.data.model.DialogFragmentModel
import com.aksantara.jobfinder.databinding.DialogFragmentJfBinding
import com.aksantara.jobfinder.ui.login.LoginActivity
import com.aksantara.jobfinder.ui.login.register.option.OptionFragment

class DialogFragmentJf(private val data: DialogFragmentModel) : DialogFragment() {

    private lateinit var binding: DialogFragmentJfBinding

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        binding = DialogFragmentJfBinding.inflate(layoutInflater)

        binding.apply {
            ivDialog.setImageResource(data.image)
            tvTitle.text = data.title
            tvDesc.text = data.description
            tvBtnSubmit.text = data.buttonText

                btnSubmit.setOnClickListener {
                val mFragmentManager = parentFragmentManager
                val mOption = OptionFragment()
                dismiss()

                //to loginFragment or optionFragment
                mFragmentManager.commit {
                    if (data.toOptionOrLogin == OptionFragment.OPTION_TEXT) {
                        addToBackStack(null)
                        replace(R.id.host_register_activity, mOption)
                    } else if (data.toOptionOrLogin == LoginActivity.LOGIN_TEXT) {
                        requireActivity().finish()
                    }
                }
            }
        }

        builder.setView(binding.root)
        return builder.create()
    }
}