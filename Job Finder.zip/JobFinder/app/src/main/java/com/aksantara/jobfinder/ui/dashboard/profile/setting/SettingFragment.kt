package com.aksantara.jobfinder.ui.dashboard.profile.setting

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.FragmentSettingBinding
import com.aksantara.jobfinder.ui.dashboard.profile.setting.editprofile.EditProfileFragment
import com.aksantara.jobfinder.ui.login.LoginActivity
import com.aksantara.jobfinder.ui.login.forgotpassword.resetpassword.ResetPasswordFragment

class SettingFragment : Fragment() {

    private lateinit var binding: FragmentSettingBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentSettingBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            btnBack.setOnClickListener {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }

            btnLogOut.setOnClickListener {
                val intent = Intent(requireActivity(), LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
            }

            btnBookmark.setOnClickListener {
                setCurrentFragment(EditProfileFragment())
            }

            btnChangePw.setOnClickListener {
                setCurrentFragment(ResetPasswordFragment())
            }

            btnEditProfile.setOnClickListener {
                setCurrentFragment(EditProfileFragment())
            }
        }

    }

    fun setCurrentFragment(fragment: Fragment) {
        requireActivity().supportFragmentManager.beginTransaction().apply {
            replace(R.id.host_setting_activity, fragment)
            addToBackStack(null)
            commit()
        }
    }

}