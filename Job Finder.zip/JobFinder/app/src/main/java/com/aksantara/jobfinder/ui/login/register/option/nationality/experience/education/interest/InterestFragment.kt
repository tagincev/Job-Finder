package com.aksantara.jobfinder.ui.login.register.option.nationality.experience.education.interest

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.FragmentJfInterestBinding
import com.aksantara.jobfinder.ui.login.register.option.nationality.experience.education.interest.registersuccess.RegisterSuccessFragment

class InterestFragment : Fragment(), View.OnClickListener {

    private lateinit var binding: FragmentJfInterestBinding

    private var isBigData = false
    private var isArt = false
    private var isFinance = false
    private var isProgrammer = false
    private var isComposer = false
    private var isWriter = false
    private var isHrd = false
    private var isPhotographer = false
    private var isGamer = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentJfInterestBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            btnBack.setOnClickListener { requireActivity().supportFragmentManager.popBackStackImmediate() }

            linearBigData.setOnClickListener(this@InterestFragment)
            linearArt.setOnClickListener(this@InterestFragment)
            linearFinance.setOnClickListener(this@InterestFragment)
            linearProgrammer.setOnClickListener(this@InterestFragment)
            linearComposer.setOnClickListener(this@InterestFragment)
            linearWriter.setOnClickListener(this@InterestFragment)
            linearHrd.setOnClickListener(this@InterestFragment)
            linearPhotographer.setOnClickListener(this@InterestFragment)
            linearGamer.setOnClickListener(this@InterestFragment)

            btnNext.setOnClickListener {
                requireActivity().supportFragmentManager.commit {
                    replace(R.id.host_register_activity, RegisterSuccessFragment())
                    addToBackStack(null)
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    @SuppressLint("UseCompatLoadingForDrawables")
    override fun onClick(p0: View?) {
        val configuration: Configuration = resources.configuration

        binding.apply {
            if (configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK === Configuration.UI_MODE_NIGHT_YES) {
                when (p0) {
                    binding.linearBigData -> {
                        if (isBigData) {
                            linearBigData.background =
                                resources.getDrawable(R.drawable.bg_edit_text_selector, null)
                            ivBigData.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvBigData.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isBigData = !isBigData
                        } else {
                            linearBigData.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivBigData.imageTintList =
                                resources.getColorStateList(R.color.white, null)
                            tvBigData.setTextColor(resources.getColor(R.color.white, null))
                            isBigData = !isBigData
                        }
                    }

                    binding.linearArt -> {
                        if (isArt) {
                            linearArt.background = resources.getDrawable(R.drawable.bg_edit_text_selector, null)
                            ivArt.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvArt.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isArt = !isArt
                        } else {
                            linearArt.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivArt.imageTintList =
                                resources.getColorStateList(R.color.white, null)
                            tvArt.setTextColor(resources.getColor(R.color.white, null))
                            isArt = !isArt
                        }
                    }

                    binding.linearFinance -> {
                        if (isFinance) {
                            linearFinance.background = resources.getDrawable(R.drawable.bg_edit_text_selector, null)
                            ivFinance.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvFinance.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isFinance = !isFinance
                        } else {
                            linearFinance.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivFinance.imageTintList =
                                resources.getColorStateList(R.color.white, null)
                            tvFinance.setTextColor(resources.getColor(R.color.white, null))
                            isFinance = !isFinance
                        }
                    }

                    binding.linearProgrammer -> {
                        if (isProgrammer) {
                            linearProgrammer.background = resources.getDrawable(R.drawable.bg_edit_text_selector, null)
                            ivProgrammer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvProgrammer.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isProgrammer = !isProgrammer
                        } else {
                            linearProgrammer.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivProgrammer.imageTintList =
                                resources.getColorStateList(R.color.white, null)
                            tvProgrammer.setTextColor(resources.getColor(R.color.white, null))
                            isProgrammer = !isProgrammer
                        }
                    }

                    binding.linearComposer -> {
                        if (isComposer) {
                            linearComposer.background = resources.getDrawable(R.drawable.bg_edit_text_selector, null)
                            ivComposer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvComposer.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isComposer = !isComposer
                        } else {
                            linearComposer.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivComposer.imageTintList =
                                resources.getColorStateList(R.color.white, null)
                            tvComposer.setTextColor(resources.getColor(R.color.white, null))
                            isComposer = !isComposer
                        }
                    }

                    binding.linearWriter -> {
                        if (isWriter) {
                            linearWriter.background = resources.getDrawable(R.drawable.bg_edit_text_selector, null)
                            ivWriter.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvWriter.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isWriter = !isWriter
                        } else {
                            linearWriter.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivWriter.imageTintList =
                                resources.getColorStateList(R.color.white, null)
                            tvWriter.setTextColor(resources.getColor(R.color.white, null))
                            isWriter = !isWriter
                        }
                    }

                    binding.linearHrd -> {
                        if (isHrd) {
                            linearHrd.background = resources.getDrawable(R.drawable.bg_edit_text_selector, null)
                            ivHrd.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvHrd.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isHrd = !isHrd
                        } else {
                            linearHrd.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivHrd.imageTintList =
                                resources.getColorStateList(R.color.white, null)
                            tvHrd.setTextColor(resources.getColor(R.color.white, null))
                            isHrd = !isHrd
                        }
                    }

                    binding.linearPhotographer -> {
                        if (isPhotographer) {
                            linearPhotographer.background = resources.getDrawable(R.drawable.bg_edit_text_selector, null)
                            ivPhotographer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvPhotographer.setTextColor(
                                resources.getColor(
                                    R.color.colorNeutral300,
                                    null
                                )
                            )
                            isPhotographer = !isPhotographer
                        } else {
                            linearPhotographer.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivPhotographer.imageTintList =
                                resources.getColorStateList(R.color.white, null)
                            tvPhotographer.setTextColor(
                                resources.getColor(
                                    R.color.white,
                                    null
                                )
                            )
                            isPhotographer = !isPhotographer
                        }
                    }

                    binding.linearGamer -> {
                        if (isGamer) {
                            linearGamer.background = resources.getDrawable(R.drawable.bg_edit_text_selector, null)
                            ivGamer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvGamer.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isGamer = !isGamer
                        } else {
                            linearGamer.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivGamer.imageTintList =
                                resources.getColorStateList(R.color.white, null)
                            tvGamer.setTextColor(resources.getColor(R.color.white, null))
                            isGamer = !isGamer
                        }
                    }
                }
            } else {
                when (p0) {
                    binding.linearBigData -> {
                        if (isBigData) {
                            linearBigData.background = resources.getDrawable(R.color.white, null)
                            ivBigData.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvBigData.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isBigData = !isBigData
                        } else {
                            linearBigData.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivBigData.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral500, null)
                            tvBigData.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                            isBigData = !isBigData
                        }
                    }

                    binding.linearArt -> {
                        if (isArt) {
                            linearArt.background = resources.getDrawable(R.color.white, null)
                            ivArt.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvArt.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isArt = !isArt
                        } else {
                            linearArt.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivArt.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral500, null)
                            tvArt.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                            isArt = !isArt
                        }
                    }

                    binding.linearFinance -> {
                        if (isFinance) {
                            linearFinance.background = resources.getDrawable(R.color.white, null)
                            ivFinance.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvFinance.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isFinance = !isFinance
                        } else {
                            linearFinance.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivFinance.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral500, null)
                            tvFinance.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                            isFinance = !isFinance
                        }
                    }

                    binding.linearProgrammer -> {
                        if (isProgrammer) {
                            linearProgrammer.background = resources.getDrawable(R.color.white, null)
                            ivProgrammer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvProgrammer.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isProgrammer = !isProgrammer
                        } else {
                            linearProgrammer.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivProgrammer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral500, null)
                            tvProgrammer.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                            isProgrammer = !isProgrammer
                        }
                    }

                    binding.linearComposer -> {
                        if (isComposer) {
                            linearComposer.background = resources.getDrawable(R.color.white, null)
                            ivComposer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvComposer.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isComposer = !isComposer
                        } else {
                            linearComposer.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivComposer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral500, null)
                            tvComposer.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                            isComposer = !isComposer
                        }
                    }

                    binding.linearWriter -> {
                        if (isWriter) {
                            linearWriter.background = resources.getDrawable(R.color.white, null)
                            ivWriter.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvWriter.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isWriter = !isWriter
                        } else {
                            linearWriter.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivWriter.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral500, null)
                            tvWriter.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                            isWriter = !isWriter
                        }
                    }

                    binding.linearHrd -> {
                        if (isHrd) {
                            linearHrd.background = resources.getDrawable(R.color.white, null)
                            ivHrd.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvHrd.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isHrd = !isHrd
                        } else {
                            linearHrd.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivHrd.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral500, null)
                            tvHrd.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                            isHrd = !isHrd
                        }
                    }

                    binding.linearPhotographer -> {
                        if (isPhotographer) {
                            linearPhotographer.background = resources.getDrawable(R.color.white, null)
                            ivPhotographer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvPhotographer.setTextColor(
                                resources.getColor(
                                    R.color.colorNeutral300,
                                    null
                                )
                            )
                            isPhotographer = !isPhotographer
                        } else {
                            linearPhotographer.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivPhotographer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral500, null)
                            tvPhotographer.setTextColor(
                                resources.getColor(
                                    R.color.colorNeutral500,
                                    null
                                )
                            )
                            isPhotographer = !isPhotographer
                        }
                    }

                    binding.linearGamer -> {
                        if (isGamer) {
                            linearGamer.background = resources.getDrawable(R.color.white, null)
                            ivGamer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral300, null)
                            tvGamer.setTextColor(resources.getColor(R.color.colorNeutral300, null))
                            isGamer = !isGamer
                        } else {
                            linearGamer.background =
                                resources.getDrawable(R.drawable.bg_jf_outline_brand_500, null)
                            ivGamer.imageTintList =
                                resources.getColorStateList(R.color.colorNeutral500, null)
                            tvGamer.setTextColor(resources.getColor(R.color.colorNeutral500, null))
                            isGamer = !isGamer
                        }
                    }
                }
            }
        }
    }
}