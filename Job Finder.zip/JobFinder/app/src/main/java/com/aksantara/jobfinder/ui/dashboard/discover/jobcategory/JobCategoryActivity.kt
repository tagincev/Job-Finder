package com.aksantara.jobfinder.ui.dashboard.discover.jobcategory

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.ActivityJobCategoryBinding
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage

class JobCategoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityJobCategoryBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityJobCategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            btnBack.setOnClickListener {
                finish()
            }
        }

        // item init
        initItem()
    }

    private fun initItem() {
        binding.apply {
            itemSponsored.apply {
                ivBackdrop.loadImage("https://picsum.photos/258/255")
                ivCompany.setImageResource(R.drawable.ic_dribbble)
                tvCompany.text = "Dribbble"
                tvPosition.text = "UI Researcher"
                tvJobType.text = "Full Time"
                tvSalary.text = "\$12k/month"
            }

            //item 1
            itemOpenJobs1.apply {
                ivCompany.setImageResource(R.drawable.ic_dribbble)
                tvPosition.text = "UI Researcher"
                tvCompany.text = "Dribbble"
                tvLocation.text = "Boulevard st. 12"
                tvTime.text = "390m away"
            }

            //item 2
            itemOpenJobs2.apply {
                tvPosition.text = "Junior UX Writer"
                tvCompany.text = "Dribbble"
                ivCompany.setImageResource(R.drawable.ic_dribbble)
                tvLocation.text = "Arcadia 51"
                tvTime.text = "2km away"
                tvSalary.text = "\$12k/month"
            }

            //item 3
            itemOpenJobs3.apply {
                ivCompany.setImageResource(R.drawable.ic_meta)
                tvPosition.text = "IOS Developer"
                tvCompany.text = "Meta"
                tvLocation.text = "Bintaro blok M"
                tvTime.text = "11km away"
            }

            //item 4
            itemOpenJobs4.apply {
                ivCompany.setImageResource(R.drawable.ic_discord)
                tvPosition.text = "Moderator"
                tvCompany.text = "Discord"
                tvLocation.text = "Bintaro blok M"
                tvTime.text = "10km away"
            }

            //item 5
            itemOpenJobs5.apply {
                ivCompany.setImageResource(R.drawable.ic_meta)
                tvPosition.text = "Junior UX Writer"
                tvCompany.text = "Meta"
                tvLocation.text = "Bintaro blok D"
                tvTime.text = "1km away"
            }
        }
    }
}