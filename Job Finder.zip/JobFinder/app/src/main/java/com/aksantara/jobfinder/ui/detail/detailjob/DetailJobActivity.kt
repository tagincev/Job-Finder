package com.aksantara.jobfinder.ui.detail.detailjob

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.commit
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.ActivityDetailJobBinding
import com.aksantara.jobfinder.ui.detail.detailcompany.DetailCompanyActivity
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage

class DetailJobActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailJobBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailJobBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            btnBack.setOnClickListener {
                onBackPressedDispatcher.onBackPressed()
            }

            linearCompany.setOnClickListener {
                val intent = Intent(this@DetailJobActivity, DetailCompanyActivity::class.java)
                startActivity(intent)
            }

            ivBackgroundHeader.loadImage("https://picsum.photos/460/460")

            ivCompany.loadImage("https://picsum.photos/360/360")
        }
    }
}