package com.aksantara.jobfinder.ui.dashboard.home.openarea

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import com.aksantara.jobfinder.R
import com.aksantara.jobfinder.databinding.ActivityOpenAreaBinding
import com.aksantara.jobfinder.databinding.BottomSheetOpenAreaBinding
import com.aksantara.jobfinder.ui.dashboard.home.filter.FilterActivity
import com.aksantara.jobfinder.utils.JfGlideHelper.loadImage
import com.google.android.material.bottomsheet.BottomSheetBehavior

class OpenAreaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOpenAreaBinding
    private lateinit var bottomSheetOpenAreaBinding: BottomSheetOpenAreaBinding
    private lateinit var sheetBehavior: BottomSheetBehavior<LinearLayout>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOpenAreaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bottomSheetOpenAreaBinding = binding.bottomSheetDialogContainer
        val mBottomSheet: LinearLayout = binding.bottomSheetDialogContainer.root
        sheetBehavior = BottomSheetBehavior.from(mBottomSheet)

        binding.apply {
            ivBackOpenArea.setOnClickListener {
                finish()
            }

            ivFilter.setOnClickListener {
                val intent = Intent(this@OpenAreaActivity, FilterActivity::class.java)
                startActivity(intent)
            }

            ivItemJob.loadImage("https://picsum.photos/258/255")

            ivMapOpenArea.setOnClickListener {
                itemOpenArea.visibility = View.VISIBLE
                ivMapOpenArea.setImageResource(R.drawable.ic_open_area_clicked)
            }
        }

        bottomSheetOpenAreaBinding.apply {
            //item 1
            itemOpenJobs1.apply {
                ivCompany.setImageResource(R.drawable.ic_dribbble)
                tvPosition.text = "UI Researcher"
                tvCompany.text = "Dribbble"
                tvLocation.text = "Boulevard st. 12"
                tvTime.text = "390m away"
            }

            //item 2
            itemOpenJobs2.apply {
                tvPosition.text = "Junior UX Writer"
                tvCompany.text = "Dribbble"
                ivCompany.setImageResource(R.drawable.ic_dribbble)
                tvLocation.text = "Arcadia 51"
                tvTime.text = "2km away"
                tvSalary.text = "\$12k/month"
            }

            //item 3
            itemOpenJobs3.apply {
                ivCompany.setImageResource(R.drawable.ic_meta)
                tvPosition.text = "IOS Developer"
                tvCompany.text = "Meta"
                tvLocation.text = "Bintaro blok M"
                tvTime.text = "11km away"
            }

            //item 4
            itemOpenJobs4.apply {
                ivCompany.setImageResource(R.drawable.ic_discord)
                tvPosition.text = "Moderator"
                tvCompany.text = "Discord"
                tvLocation.text = "Bintaro blok M"
                tvTime.text = "10km away"
            }

            //item 5
            itemOpenJobs5.apply {
                ivCompany.setImageResource(R.drawable.ic_meta)
                tvPosition.text = "Junior UX Writer"
                tvCompany.text = "Meta"
                tvLocation.text = "Bintaro blok D"
                tvTime.text = "1km away"
            }
        }
    }
}